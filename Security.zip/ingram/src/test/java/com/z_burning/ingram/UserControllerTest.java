package com.z_burning.ingram;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.HashSet;
import java.util.Set;

import static org.junit.Assert.*;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest
public class UserControllerTest {

    @Test
    public void ladder()
        throws Exception {
            Set<String> dict = new HashSet<>();
            Judge wordPairs = new Judge();
            wordPairs.wordOne = "code";
            wordPairs.wordTwo = "data";

            File findFile = new File("target/dictionary.txt");
            if (findFile.exists()) {
                BufferedReader fileReader = new BufferedReader(new FileReader(findFile));
                String dict_word = fileReader.readLine();
                while (dict_word != null) {
                    dict.add(dict_word);
                    dict_word = fileReader.readLine();
                }
            } else {
                System.out.println(" file error");
                return;
            }

            if( !wordPairs.judge_length() )
            {
                System.out.println("Same Length");
            }
            else if( !wordPairs.judge_equality() )
            {
                System.out.println("Not Same words");
            }
            else if( !wordPairs.judge_containing(dict) )
            {
                System.out.println("Valid words");
            }
    }
}